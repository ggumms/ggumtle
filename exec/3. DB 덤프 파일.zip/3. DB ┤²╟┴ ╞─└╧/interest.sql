/*
-- Query: select * from interest
-- Date: 2024-02-15 21:07
*/
INSERT INTO `interest` (`id`,`name`) VALUES (1,'환경');
INSERT INTO `interest` (`id`,`name`) VALUES (2,'자선활동');
INSERT INTO `interest` (`id`,`name`) VALUES (3,'인간관계');
INSERT INTO `interest` (`id`,`name`) VALUES (4,'휴식');
INSERT INTO `interest` (`id`,`name`) VALUES (5,'연애');
INSERT INTO `interest` (`id`,`name`) VALUES (6,'운동');
INSERT INTO `interest` (`id`,`name`) VALUES (7,'여행');
INSERT INTO `interest` (`id`,`name`) VALUES (8,'언어');
INSERT INTO `interest` (`id`,`name`) VALUES (9,'문화');
INSERT INTO `interest` (`id`,`name`) VALUES (10,'도전');
INSERT INTO `interest` (`id`,`name`) VALUES (11,'취미');
INSERT INTO `interest` (`id`,`name`) VALUES (12,'직장');
