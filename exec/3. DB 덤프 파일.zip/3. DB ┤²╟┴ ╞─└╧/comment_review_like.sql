/*
-- Query: select * from comment_review_like
-- Date: 2024-02-15 21:06
*/
INSERT INTO `comment_review_like` (`id`,`comment_id`,`user_id`) VALUES (4,12,3);
